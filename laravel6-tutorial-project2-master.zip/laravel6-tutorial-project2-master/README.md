# Laravel 6 Tutorial

This Tutorial is by **ALGORITHM**
[Visit My Channel](https://www.youtube.com/c/algorithmCoding)

## Project2 : Demo Blog App with Laravel Framework


### Content of Project 2

- Authentication
- Models & Migrations
- Resource-controller and Named Routes
- Mass Assignment
- Form Request Validation
- Route Model Binding
- Relationships
- Soft Deleting
- Middleware
- File Storage
- and much more ...
